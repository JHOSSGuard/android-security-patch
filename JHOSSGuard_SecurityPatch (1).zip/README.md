# Security Patch for Privileged Preinstalled Apps  
**Researcher Alias:** JHOSSGuard  

## Overview  
This patch addresses a **critical security vulnerability** in Android where a **privileged preinstalled application** can:  
- Persist after attempted removal.  
- Abuse elevated permissions.  
- Initiate unauthorized network connections.  
- Operate without explicit user consent.  

The changes enforce stricter controls at both **SELinux policy** and **PackageManagerService** level.  

---

## Changes Introduced  

### 1. SELinux Policy (`system/sepolicy/private/app.te`)  
- Blocks privileged preinstalled apps (`priv_app`) from connecting to sockets.  
- Prevents unauthorized access to `system_server` services.  

### 2. PackageManagerService (`frameworks/base/services/core/java/com/android/server/pm/PackageManagerService.java`)  
- Ensures preinstalled privileged apps are marked **removable** by the user.  
- Denies hidden or unauthorized dangerous permissions unless explicitly whitelisted.  
- Throws security exceptions and logs blocked permission abuse.  

---

## Patch File  
The patch is included in this repository as:  

```
security_patch_jhossguard.patch
```

To apply it:  

```bash
git apply security_patch_jhossguard.patch
```

---

## Mitigation Value  
- Eliminates persistence of backdoored privileged apps.  
- Protects against unauthorized data exfiltration.  
- Strengthens user control and trust in the Android ecosystem.  

---

## Recommendation for Google / AOSP  
Integrate these protections into **future Android builds** and enforce them in **CTS/GTS compliance tests** to prevent OEMs from shipping unsafe privileged applications.  

---

## Researcher Recognition  
This patch was developed by **JHOSSGuard** as part of responsible disclosure under the Google VRP program.  
